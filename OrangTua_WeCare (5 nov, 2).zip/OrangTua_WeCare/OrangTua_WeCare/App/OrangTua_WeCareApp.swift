//
//  OrangTua_WeCareApp.swift
//  OrangTua_WeCare
//
//  Created by Student on 05/11/25.
//

import SwiftUI

@main
struct OrangTua_WeCareApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
