import SwiftUI

// MARK: - Sudoku View (Accessed from GamesView)

struct SudokuView: View {
    @StateObject var game = SudokuGame()
    @Environment(\.dismiss) var dismiss
    
    var selectedCell: (row: Int, col: Int)? {
        if let cell = game.board.flatMap({ $0 }).first(where: { $0.isSelected }) {
            let row = game.board.firstIndex(where: { $0.contains(where: { $0.id == cell.id }) })!
            let col = game.board[row].firstIndex(where: { $0.id == cell.id })!
            return (row, col)
        }
        return nil
    }
    
    var body: some View {
        VStack(spacing: 20) {
            
            // MARK: - Header & Back Button
            HStack {
                Text("Sudoku Game")
                    .font(.largeTitle.bold())
                    .foregroundColor(Color(hex: "#387b38"))
                Spacer()
                Button("Back") {
                    dismiss()
                }
                .font(.title3.bold())
                .foregroundColor(.black)
                .padding(8)
                .background(Color(hex: "#fdcb46"))
                .cornerRadius(10)
            }
            .padding([.horizontal, .top])
            
            // MARK: - Game Status
            Text(game.gameStatus)
                .font(.title3.bold())
                .foregroundColor(game.gameStatus.contains("Congratulations") ? Color(hex: "#387b38") : Color(hex: "#fa6255"))
                .padding(.horizontal)
            
            // MARK: - Sudoku Grid
            VStack(spacing: 1) {
                ForEach(0..<9, id: \.self) { row in
                    HStack(spacing: 1) {
                        ForEach(0..<9, id: \.self) { col in
                            CellView(cell: game.board[row][col],
                                     row: row,
                                     col: col,
                                     game: game,
                                     selectedCell: selectedCell)
                                .padding(.trailing, (col + 1) % 3 == 0 && col != 8 ? 2 : 0)
                                .padding(.bottom, (row + 1) % 3 == 0 && row != 8 ? 2 : 0)
                        }
                    }
                }
            }
            .background(Color.black)
            .padding(.horizontal)
            
            Spacer()

            // MARK: - Number Input Pad
            NumberPad(game: game)
                .padding(.bottom, 10)
            
            // MARK: - Action Button
            Button("Start New Game") {
                game.restartGame()
            }
            .font(.title2.bold())
            .padding(15)
            .frame(maxWidth: .infinity)
            .background(Color(hex: "#fa6255"))
            .foregroundColor(.white)
            .cornerRadius(15)
            .padding(.horizontal)
            
        }
        .padding(.top, 20)
        .background(Color(.systemGray6).ignoresSafeArea())
    }
}

// MARK: - Cell Component

struct CellView: View {
    let cell: SudokuCell
    let row: Int
    let col: Int
    @ObservedObject var game: SudokuGame
    let selectedCell: (row: Int, col: Int)?
    
    var isHighlighted: Bool {
        guard let selected = selectedCell else { return false }
        
        // Highlight same row and column
        if row == selected.row || col == selected.col { return true }
        
        // Highlight same 3x3 box
        let selectedBox = (selected.row / 3, selected.col / 3)
        let currentBox = (row / 3, col / 3)
        return selectedBox == currentBox
    }
    
    var body: some View {
        Text(cell.value != nil ? "\(cell.value!)" : "")
            .font(.title.bold())
            .frame(width: 40, height: 40)
            .background(backgroundColor)
            .foregroundColor(foregroundColor)
            .border(Color.black.opacity(0.1), width: 0.5)
            .contentShape(Rectangle())
            .onTapGesture {
                // >>> CHANGE HERE <<<
                // Removed 'if cell.isEditable' check.
                // Now all cells (editable or pre-filled) can be tapped for selection and highlighting.
                game.selectCell(row: row, col: col)
            }
    }
    
    var foregroundColor: Color {
        if cell.isEditable {
            return cell.isError ? Color(hex: "#fa6255") : .blue
        } else {
            return .black // Initial value: Black
        }
    }
    
    var backgroundColor: Color {
        if cell.isSelected {
            return Color(hex: "#959595").opacity(0.9) // Selected cell
        } else if cell.initialValue != nil {
            return Color(.systemGray5) // Pre-filled value
        } else if isHighlighted {
            return Color(hex: "#d0d0d0")
        } else {
            return .white // Empty cell
        }
    }
}

// MARK: - Number Pad

struct NumberPad: View {
    @ObservedObject var game: SudokuGame
    
    var body: some View {
        VStack(spacing: 15) {
            HStack(spacing: 15) {
                ForEach(1...5, id: \.self) { number in
                    NumberButton(number: number, game: game)
                }
            }
            HStack(spacing: 15) {
                ForEach(6...9, id: \.self) { number in
                    NumberButton(number: number, game: game)
                }
                ClearButton(game: game)
            }
        }
        .padding(.horizontal)
    }
}

// MARK: - Number Buttons

struct NumberButton: View {
    let number: Int
    @ObservedObject var game: SudokuGame
    
    var body: some View {
        Button(action: {
            game.enterValue(value: number)
        }) {
            Text("\(number)")
                .font(.title2.bold())
                .frame(width: 55, height: 55)
                .background(Color(hex: "#387b38"))
                .foregroundColor(.white)
                .cornerRadius(12)
        }
        // Input buttons remain disabled if the selected cell cannot be edited.
        .disabled(game.board.flatMap { $0 }.first(where: { $0.isSelected && $0.isEditable }) == nil)
    }
}

// MARK: - Clear Button

struct ClearButton: View {
    @ObservedObject var game: SudokuGame
    
    var body: some View {
        Button(action: {
            game.enterValue(value: nil)
        }) {
            Image(systemName: "xmark.circle.fill")
                .font(.title2.bold())
                .frame(width: 55, height: 55)
                .background(Color(.systemGray3))
                .foregroundColor(.white)
                .cornerRadius(12)
        }
        // Input buttons remain disabled if the selected cell cannot be edited.
        .disabled(game.board.flatMap { $0 }.first(where: { $0.isSelected && $0.isEditable }) == nil)
    }
}

#Preview {
    SudokuView()
}
