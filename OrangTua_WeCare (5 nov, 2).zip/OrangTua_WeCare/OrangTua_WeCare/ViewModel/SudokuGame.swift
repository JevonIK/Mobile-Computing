import Foundation

// MARK: - Sudoku Game Model & Logic

struct SudokuCell: Identifiable {
    let id = UUID()
    var value: Int? // Current value (can be filled by player or empty)
    let initialValue: Int? // Initial value (cannot be changed)
    var isSelected: Bool = false
    var isError: Bool = false // Flag indicating if this cell has a conflict
    
    var isEditable: Bool {
        return initialValue == nil
    }
}

class SudokuGame: ObservableObject {
    @Published var board: [[SudokuCell]] = []
    @Published var gameStatus: String = "Have fun playing!"
    
    private var solvedBoard: [[Int]] = [] // Solution board for validation
    
    init() {
        // Easier board for seniors
        let preset = SudokuGenerator.generateEasyBoard()
        self.board = SudokuGame.createBoard(initial: preset.initial, solution: preset.solution)
        self.solvedBoard = preset.solution
    }
    
    private static func createBoard(initial: [[Int]], solution: [[Int]]) -> [[SudokuCell]] {
        var newBoard: [[SudokuCell]] = []
        for row in 0..<9 {
            var newRow: [SudokuCell] = []
            for col in 0..<9 {
                let initialVal = initial[row][col] == 0 ? nil : initial[row][col]
                newRow.append(SudokuCell(
                    value: initialVal,
                    initialValue: initialVal
                ))
            }
            newBoard.append(newRow)
        }
        return newBoard
    }
    
    // MARK: - Player Interaction
    
    func selectCell(row: Int, col: Int) {
        // Deselect all cells
        for r in 0..<9 {
            for c in 0..<9 {
                board[r][c].isSelected = false
            }
        }
        
        // Select the new cell
        board[row][col].isSelected = true
    }
    
    func enterValue(value: Int?) {
        for row in 0..<9 {
            for col in 0..<9 {
                if board[row][col].isSelected && board[row][col].isEditable {
                    board[row][col].value = value
                    
                    // Validate and check for win after input
                    validateBoard()
                    checkForWin()
                    return
                }
            }
        }
    }
    
    // MARK: - Validation & Win Check
    
    private func validateBoard() {
        for row in 0..<9 {
            for col in 0..<9 {
                board[row][col].isError = false
                
                guard let currentValue = board[row][col].value else { continue }
                
                // Check for row, column, and 3x3 block conflicts
                if !isValidPlacement(row: row, col: col, value: currentValue) {
                    board[row][col].isError = true
                }
            }
        }
    }
    
    private func isValidPlacement(row: Int, col: Int, value: Int) -> Bool {
        // Check row and column
        for i in 0..<9 {
            // Check row (excluding the cell itself)
            if i != col && board[row][i].value == value { return false }
            // Check column (excluding the cell itself)
            if i != row && board[i][col].value == value { return false }
        }
        
        // Check 3x3 block
        let startRow = (row / 3) * 3
        let startCol = (col / 3) * 3
        for r in startRow..<startRow + 3 {
            for c in startCol..<startCol + 3 {
                if r != row && c != col && board[r][c].value == value { return false }
            }
        }
        
        return true
    }
    
    func checkForWin() {
        // Check for empty cells or errors
        let hasEmptyCells = board.flatMap { $0 }.contains { $0.value == nil }
        let hasErrors = board.flatMap { $0 }.contains { $0.isError }
        
        if hasEmptyCells || hasErrors {
            gameStatus = "Have fun playing!"
            return
        }
        
        // If no errors and all filled, check against solution
        var isSolvedCorrectly = true
        for row in 0..<9 {
            for col in 0..<9 {
                if board[row][col].value != solvedBoard[row][col] {
                    isSolvedCorrectly = false
                    break
                }
            }
            if !isSolvedCorrectly { break }
        }
        
        if isSolvedCorrectly {
            gameStatus = "🎉 Congratulations! You completed the Sudoku!"
        } else {
            // Technically should not happen if validation works correctly,
            // but serves as a fallback for hidden conflicts.
            gameStatus = "Conflict detected! Please check again."
        }
    }
    
    // Start a new game
    func restartGame() {
        let preset = SudokuGenerator.generateEasyBoard()
        self.board = SudokuGame.createBoard(initial: preset.initial, solution: preset.solution)
        self.solvedBoard = preset.solution
        self.gameStatus = "Have fun playing!"
    }
}

// MARK: - SudokuGenerator (Simple Dummy Board & Solution)

struct SudokuGenerator {
    // Returns a VERY EASY Sudoku board and solution
    static func generateEasyBoard() -> (initial: [[Int]], solution: [[Int]]) {
        
        // Initial board (0 = empty)
        let initialBoard: [[Int]] = [
            [5, 3, 0, 0, 7, 0, 0, 0, 0],
            [6, 0, 0, 1, 9, 5, 0, 0, 0],
            [0, 9, 8, 0, 0, 0, 0, 6, 0],
            [8, 0, 0, 0, 6, 0, 0, 0, 3],
            [4, 0, 0, 8, 0, 3, 0, 0, 1],
            [7, 0, 0, 0, 2, 0, 0, 0, 6],
            [0, 6, 0, 0, 0, 0, 2, 8, 0],
            [0, 0, 0, 4, 1, 9, 0, 0, 5],
            [0, 0, 0, 0, 8, 0, 0, 7, 9]
        ]
        
        // Solution board (for win validation)
        let solvedBoard: [[Int]] = [
            [5, 3, 4, 6, 7, 8, 9, 1, 2],
            [6, 7, 2, 1, 9, 5, 3, 4, 8],
            [1, 9, 8, 3, 4, 2, 5, 6, 7],
            [8, 5, 9, 7, 6, 1, 4, 2, 3],
            [4, 2, 6, 8, 5, 3, 7, 9, 1],
            [7, 1, 3, 9, 2, 4, 8, 5, 6],
            [9, 6, 1, 5, 3, 7, 2, 8, 4],
            [2, 8, 7, 4, 1, 9, 6, 3, 5],
            [3, 4, 5, 2, 8, 6, 1, 7, 9]
        ]
        
        return (initialBoard, solvedBoard)
    }
}
