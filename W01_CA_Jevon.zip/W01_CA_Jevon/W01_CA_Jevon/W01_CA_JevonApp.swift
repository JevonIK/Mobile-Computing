//
//  W01_CA_JevonApp.swift
//  W01_CA_Jevon
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_CA_JevonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
