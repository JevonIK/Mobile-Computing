//
//  W01_CA_JevonTests.swift
//  W01_CA_JevonTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_CA_Jevon

struct W01_CA_JevonTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
