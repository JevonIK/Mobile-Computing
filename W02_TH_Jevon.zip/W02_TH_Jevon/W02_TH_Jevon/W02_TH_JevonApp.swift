//
//  W02_TH_JevonApp.swift
//  W02_TH_Jevon
//
//  Created by student on 23/09/25.
//

import SwiftUI

@main
struct W02_TH_JevonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
