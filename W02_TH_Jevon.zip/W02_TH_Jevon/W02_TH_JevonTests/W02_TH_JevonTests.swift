//
//  W02_TH_JevonTests.swift
//  W02_TH_JevonTests
//
//  Created by student on 23/09/25.
//

import Testing
@testable import W02_TH_Jevon

struct W02_TH_JevonTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
