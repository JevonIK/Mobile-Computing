//
//  W03_TH_JevonApp.swift
//  W03_TH_Jevon
//
//  Created by student on 30/09/25.
//

import SwiftUI

@main
struct W03_TH_JevonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
