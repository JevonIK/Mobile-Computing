//
//  W03_TH_JevonTests.swift
//  W03_TH_JevonTests
//
//  Created by student on 30/09/25.
//

import Testing
@testable import W03_TH_Jevon

struct W03_TH_JevonTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
