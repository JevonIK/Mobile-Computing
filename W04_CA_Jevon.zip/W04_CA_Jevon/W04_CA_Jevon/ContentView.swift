//
//  ContentView.swift
//  W04_CA_Jevon
//
//  Created by student on 02/10/25.
// Jevon Ivander K / 0706022310028
// Class Assignment Mobile Computing Week 04 (2 oct 2025)



import SwiftUI

struct ContentView: View {
    var body: some View {
        // ContentView bertugas untuk memanggil tampilan utama aplikasi, yaitu MovieGridView.
        MovieGridView()
    }
}

#Preview {
    ContentView()
}
