//
//  W04_CA_JevonApp.swift
//  W04_CA_Jevon
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_CA_JevonApp: App {
    var body: some Scene {
        WindowGroup {
            MovieGridView()
        }
    }
}


