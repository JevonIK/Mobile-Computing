//
//  W04_CA_JevonTests.swift
//  W04_CA_JevonTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_CA_Jevon

struct W04_CA_JevonTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
