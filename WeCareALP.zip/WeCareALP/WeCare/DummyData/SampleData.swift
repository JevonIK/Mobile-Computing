////
////  SampleData.swift
////  WeCare
////
////  Created by student on 13/11/25.
////
//
//
////
////  SampleData.swift
////  wecare kevin
////
////  Created by student on 05/11/25.
////
//import Foundation
//enum SampleData {
//    static let demoList: [PersonCardViewData] = [
//        .init(
//            id: .init(),
//            name: "Nenek Siti",
//            role: "Grandmother",
//            avatarURL: nil,
//            heartRateText: "76 bpm",
//            steps: 3250,
//            status: .healthy,
//            latitude: -7.2575, longitude: 112.7521 // ✅ Surabaya
//        ),
//        .init(
//            id: .init(),
//            name: "Kakek Budi",
//            role: "Grandfather",
//            avatarURL: nil,
//            heartRateText: "82 bpm",
//            steps: 1800,
//            status: .warning,
//            latitude: -7.2575, longitude: 112.7521 // ✅ Surabaya
//        ),
//        .init(
//            id: .init(),
//            name: "Om Rudi",
//            role: "Uncle",
//            avatarURL: nil,
//            heartRateText: "95 bpm",
//            steps: 1540,
//            status: .critical,
//            latitude: -7.2575, longitude: 112.7521 // ✅ Surabaya
//        )
//    ]
//}
//
//
//
